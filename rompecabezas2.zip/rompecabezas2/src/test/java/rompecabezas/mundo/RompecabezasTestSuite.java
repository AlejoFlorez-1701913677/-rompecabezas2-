package rompecabezas.mundo;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
   FichaTest.class,
   FiguraTest.class,
   JuegoRompecabezasTest.class
})
public class RompecabezasTestSuite {
}
