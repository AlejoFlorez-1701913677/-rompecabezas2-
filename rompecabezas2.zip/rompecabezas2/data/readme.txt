Imagenes tomadas de:
http://members.lycos.nl/fotoworks/ballons.jpg
http://www.darknessandlight.co.uk/landscape_pictures/fs-bw/landscape-photos-beach-1014.jpg
http://www.trc.org.ls/images/picture_galleries_landscape/sunflower.jpg
http://go.hrw.com/atlas/norm_map/colombia.gif
http://cupi2.uniandes.edu.co/recursos/downloads/proyecto/logoCUPI2Grande.jpg
http://www.cocktaildesigners.com/2004/images/puzzle.jpg